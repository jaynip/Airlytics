import google.generativeai as genai
import pandas as pd
import logging
import os

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def get_ai_recommendations(df):
    """
    Generate AI-powered recommendations and insights based on the data.
    
    Args:
        df (pandas.DataFrame): The processed air quality data
        
    Returns:
        str: AI-generated recommendations and insights
    """
    # Get API key from environment variable with fallback
    gemini_api_key = os.getenv("GEMINI_API_KEY", "AIzaSyAeRYT_M-gbsPopT42wygWBUDx9pCFsdWI")
    genai.configure(api_key=gemini_api_key)
    
    # Create a summary of the dataset for the AI
    summary = f"""
    Dataset Summary:
    - Number of rows: {len(df)}
    - Number of columns: {len(df.columns)}
    - Columns and data types: {df.dtypes.to_dict()}
    - Basic statistics: {df.describe().to_dict()}
    - Sample data (first 5 rows): {df.head().to_dict()}
    - Unique Device IDs: {df['Device_ID'].unique().tolist()}
    - Unique Geohashes: {df['Geohash'].unique().tolist() if 'Geohash' in df.columns else 'Not available'}

    The dataset contains environmental sensor data with the following columns:
    - Datetime: Timestamp of the measurement
    - FAN: Fan status (binary)
    - Humidity: Relative humidity (%)
    - PM2.5: Particulate matter 2.5 (µg/m³)
    - PM10: Particulate matter 10 (µg/m³)
    - PM1: Particulate matter 1 (µg/m³)
    - PM100: Particulate matter 100 (µg/m³)
    - S1: Sensor 1 reading
    - SG: Sensor group reading
    - Temperature: Temperature (°C)
    - Wind_Direction: Wind direction (degrees)
    - Wind_Speed: Wind speed (m/s)
    - P1_CF, P2_CF, P3_CF, P4_CF, HUM_CF, TEMP_CF: Calibration factors
    - Time: Time of day (HH:MM:SS)
    - Device_ID: Device identifier
    - Geohash: Geospatial hash (precision 7, approx. 153m resolution)

    Please analyze the air quality data and provide the following:
    
    1. Key observations about the air quality metrics (PM2.5, PM10, etc.)
    2. Potential relationships between variables (correlations, patterns)
    3. Temporal trends (time of day, day of week patterns if visible)
    4. Device-specific insights (any devices showing unusual readings)
    5. Health implications based on the observed air quality levels
    6. Recommendations for further data collection or analysis
    
    Format your response in markdown with clear headings and bullet points.
    """
    
    try:
        # Create a more detailed analysis using correlation data
        if all(x in df.columns for x in ['PM2.5', 'PM10', 'Temperature', 'Humidity']):
            # Calculate key statistics
            avg_pm25 = df['PM2.5'].mean()
            avg_pm10 = df['PM10'].mean()
            
            # Calculate correlations
            corr_data = df[['PM2.5', 'PM10', 'Temperature', 'Humidity']].corr()
            
            # Add to summary
            summary += f"\n\nAdditional analysis:\n"
            summary += f"- Average PM2.5: {avg_pm25:.2f} µg/m³\n"
            summary += f"- Average PM10: {avg_pm10:.2f} µg/m³\n"
            summary += f"- Correlation between PM2.5 and Temperature: {corr_data.loc['PM2.5', 'Temperature']:.2f}\n"
            summary += f"- Correlation between PM2.5 and Humidity: {corr_data.loc['PM2.5', 'Humidity']:.2f}\n"
        
        # Generate AI recommendations
        model = genai.GenerativeModel('gemini-1.5-flash')
        response = model.generate_content(summary)
        recommendations = response.text
        
        return recommendations
    except Exception as e:
        error_message = f"Error getting AI recommendations: {str(e)}"
        logger.error(error_message)
        return f"""
        ## Error in AI Analysis
        
        There was an error generating AI recommendations: {str(e)}
        
        ### Possible reasons:
        - API key may be invalid
        - Connection issues
        - Data format incompatible with the AI model
        
        Please try again later or contact the administrator.
        """
