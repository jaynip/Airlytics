import pandas as pd
import numpy as np
import os
import logging
import google.generativeai as genai
import streamlit as st

# Set up logging
logger = logging.getLogger(__name__)

def get_ai_recommendations(df):
    """
    Get AI-based recommendations using Google's Generative AI.
    
    Args:
        df: pandas.DataFrame - The data to analyze
        
    Returns:
        str: AI-generated recommendations
    """
    # Get API key from environment variable or Streamlit secrets
    api_key = os.getenv("GEMINI_API_KEY")
    
    # Check if key exists in session state
    if 'gemini_api_key' in st.session_state and st.session_state.gemini_api_key:
        api_key = st.session_state.gemini_api_key
    
    if not api_key:
        return ("⚠️ Gemini API key not found. Please provide a Gemini API key "
                "in the settings to enable AI-powered recommendations.")
    
    if df is None or df.empty:
        return "⚠️ No data available for AI analysis."
    
    try:
        # Configure Gemini
        genai.configure(api_key=api_key)
        
        # Prepare data summary for AI
        summary = generate_data_summary(df)
        
        # Request AI analysis
        model = genai.GenerativeModel('gemini-1.5-flash')
        response = model.generate_content(summary)
        recommendations = response.text
        
        return recommendations
    except Exception as e:
        logger.error(f"Error getting AI recommendations: {e}")
        return f"⚠️ Error getting AI recommendations: {str(e)}"

def generate_data_summary(df):
    """
    Generate a summary of the dataset to send to the AI model.
    
    Args:
        df: pandas.DataFrame - The data to summarize
        
    Returns:
        str: Text summary of the data
    """
    # Basic dataset info
    num_rows = len(df)
    num_cols = len(df.columns)
    
    # Get unique devices
    device_ids = df['Device_ID'].unique().tolist() if 'Device_ID' in df.columns else []
    
    # Calculate basic stats for key metrics
    key_metrics = ['PM2.5', 'PM10', 'PM1', 'Temperature', 'Humidity', 'Wind_Speed']
    available_metrics = [m for m in key_metrics if m in df.columns]
    
    stats_dict = {}
    for metric in available_metrics:
        stats_dict[metric] = {
            'mean': df[metric].mean(),
            'median': df[metric].median(),
            'min': df[metric].min(),
            'max': df[metric].max(),
            'std': df[metric].std()
        }
    
    # Calculate correlations
    corr_matrix = None
    if len(available_metrics) > 1:
        corr_df = df[available_metrics].copy()
        corr_matrix = corr_df.corr().to_dict()
    
    # Time analysis
    time_range = None
    if 'Datetime' in df.columns:
        start_time = df['Datetime'].min()
        end_time = df['Datetime'].max()
        time_range = f"{start_time} to {end_time}"
    
    # Compose the summary text
    summary = f"""
    Dataset Summary:
    - Number of rows: {num_rows}
    - Number of columns: {num_cols}
    - Columns: {', '.join(df.columns)}
    - Unique Device IDs: {device_ids}
    
    Time Range: {time_range if time_range else 'Not available'}
    
    Basic Statistics:
    {format_stats_for_ai(stats_dict)}
    
    Correlation Matrix:
    {format_correlation_for_ai(corr_matrix) if corr_matrix else 'Not available'}
    
    Sample Data (5 rows):
    {df.head(5).to_string()}
    
    Based on this air quality monitoring data, please provide:
    
    1. Key relationships and patterns observed in the data
    2. What visualization types would best highlight these patterns
    3. Any noteworthy anomalies or unusual patterns in the data
    4. Recommendations for monitoring/improving air quality based on these readings
    5. Any health concerns based on pollution levels in the data
    
    Please format your response with clear section headings and bullet points for clarity.
    """
    
    return summary

def format_stats_for_ai(stats_dict):
    """Format statistics dictionary into readable text for AI prompt"""
    formatted_text = ""
    for metric, stats in stats_dict.items():
        formatted_text += f"  * {metric}: mean={stats['mean']:.2f}, median={stats['median']:.2f}, "
        formatted_text += f"min={stats['min']:.2f}, max={stats['max']:.2f}, std={stats['std']:.2f}\n"
    return formatted_text

def format_correlation_for_ai(corr_matrix):
    """Format correlation matrix into readable text for AI prompt"""
    formatted_text = ""
    for var1, correlations in corr_matrix.items():
        for var2, value in correlations.items():
            if var1 != var2:  # Skip self-correlations
                formatted_text += f"  * {var1} vs {var2}: {value:.2f}\n"
    return formatted_text

def get_threshold_recommendations(df):
    """
    Generate recommendations based on pollutant thresholds.
    
    Args:
        df: pandas.DataFrame - The air quality data
        
    Returns:
        dict: Recommendations for each pollutant
    """
    recommendations = {}
    
    # PM2.5 thresholds (in µg/m³)
    if 'PM2.5' in df.columns:
        pm25_avg = df['PM2.5'].mean()
        if pm25_avg < 12:
            recommendations['PM2.5'] = {
                'level': 'Good',
                'description': 'PM2.5 levels are within the healthy range.',
                'advice': 'Continue monitoring and maintaining good air quality practices.'
            }
        elif pm25_avg < 35.5:
            recommendations['PM2.5'] = {
                'level': 'Moderate',
                'description': 'PM2.5 levels are moderately elevated.',
                'advice': 'Sensitive individuals should consider reducing prolonged outdoor exertion.'
            }
        elif pm25_avg < 55.5:
            recommendations['PM2.5'] = {
                'level': 'Unhealthy for Sensitive Groups',
                'description': 'PM2.5 levels may affect sensitive groups.',
                'advice': 'Sensitive groups should reduce outdoor activity. Consider using air purifiers indoors.'
            }
        else:
            recommendations['PM2.5'] = {
                'level': 'Unhealthy',
                'description': 'PM2.5 levels are unhealthy.',
                'advice': 'Everyone should reduce outdoor exertion. Use air purifiers and keep windows closed.'
            }
    
    # PM10 thresholds (in µg/m³)
    if 'PM10' in df.columns:
        pm10_avg = df['PM10'].mean()
        if pm10_avg < 54:
            recommendations['PM10'] = {
                'level': 'Good',
                'description': 'PM10 levels are within the healthy range.',
                'advice': 'Continue monitoring and maintaining good air quality practices.'
            }
        elif pm10_avg < 154:
            recommendations['PM10'] = {
                'level': 'Moderate',
                'description': 'PM10 levels are moderately elevated.',
                'advice': 'Sensitive individuals should consider reducing prolonged outdoor exertion.'
            }
        elif pm10_avg < 254:
            recommendations['PM10'] = {
                'level': 'Unhealthy for Sensitive Groups',
                'description': 'PM10 levels may affect sensitive groups.',
                'advice': 'Sensitive groups should reduce outdoor activity. Consider using air purifiers indoors.'
            }
        else:
            recommendations['PM10'] = {
                'level': 'Unhealthy',
                'description': 'PM10 levels are unhealthy.',
                'advice': 'Everyone should reduce outdoor exertion. Use air purifiers and keep windows closed.'
            }
    
    return recommendations
