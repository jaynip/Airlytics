import pandas as pd
import numpy as np
import re
import io
import logging
import geohash2
from datetime import datetime
import streamlit as st

# Set up logging
logger = logging.getLogger(__name__)

# Device coordinates mapping (latitude, longitude)
DEVICE_COORDINATES = {
    523005: (23.02909505, 72.49078965),
    523011: (23.0309101, 72.5088321),
    523047: (23.0692036, 72.5653925),
    523082: (23.0850114, 72.5751516),
    523093: (23.096915, 72.527362),
    524037: (23.04836488, 72.68863108),
    524046: (23.0428964, 72.4749039),
    524049: (23.0777287, 72.5056656),
    524062: (23.12348122, 72.53853052),
    524089: (23.02815923, 72.50001528),
    524091: (23.0087287, 72.4551301),
}


def upload_and_process_data(uploaded_files):
    """
    Process uploaded files and return a cleaned merged DataFrame.
    
    Args:
        uploaded_files: List of uploaded file objects from Streamlit
        
    Returns:
        pandas.DataFrame: Cleaned and merged data
    """
    if not uploaded_files:
        logger.error("No files uploaded.")
        return None
    
    all_data = []
    all_columns = set()
    
    # Create a mapping of device IDs to geohash
    device_geohash = {}
    for device_id, (lat, lon) in DEVICE_COORDINATES.items():
        try:
            # Make sure coordinates are properly formatted
            lat_float = float(lat)
            lon_float = float(lon)
            device_geohash[device_id] = geohash2.encode(lat_float, lon_float, precision=7)
        except Exception as e:
            logger.error(f"Error encoding geohash for device {device_id}: {e}")
            # Skip this device
    
    for uploaded_file in uploaded_files:
        try:
            # Get file contents
            file_content = uploaded_file.read()
            
            # Determine file extension
            file_name = uploaded_file.name
            file_extension = file_name.split('.')[-1].lower()
            
            # Load data based on file extension
            if file_extension == 'csv':
                df = pd.read_csv(io.BytesIO(file_content), encoding='utf-8-sig', delimiter=',', dtype={'To Date': str})
            elif file_extension in ['xls', 'xlsx']:
                df = pd.read_excel(io.BytesIO(file_content), dtype={'To Date': str})
            else:
                logger.warning(f"Unsupported file format: {file_name}")
                continue
            
            df.columns = df.columns.str.strip()
            
            # Datetime conversion
            if "To Date" in df.columns:
                df.rename(columns={"To Date": "Datetime"}, inplace=True)
                df["Datetime"] = pd.to_datetime(df["Datetime"], format="%d-%m-%Y %H:%M", errors="coerce", dayfirst=True)
                if df["Datetime"].isna().any():
                    logger.warning(f"Some Datetime values invalid in {file_name}; attempting fallback parsing.")
                    df["Datetime"] = pd.to_datetime(df["Datetime"], dayfirst=True, errors="coerce")
                df["Time"] = df["Datetime"].dt.strftime('%H:%M:%S')
                if df["Datetime"].isna().all():
                    logger.error(f"All Datetime values are NaT in {file_name}. Skipping.")
                    continue
            else:
                logger.error(f"'To Date' column not found in {file_name}. Skipping.")
                continue
            
            # Rename columns
            column_mapping = {
                'PM₂.₅ (µg/m³)': 'PM2.5', 'PM₁₀ (µg/m³)': 'PM10', 'PM₁ (µg/m³ )': 'PM1',
                'PM₁₀₀ (µg/m³ )': 'PM100', 'R. Humidity (%)': 'Humidity',
                'Temperature (°C)': 'Temperature', 'wind direction (degree)': 'Wind_Direction',
                'wind speed (m/s)': 'Wind_Speed'
            }
            df.rename(columns=column_mapping, inplace=True)
            all_columns.update(df.columns)
            
            # Extract Device_ID from filename (e.g., AQ0523005.csv -> 523005)
            device_id_match = re.search(r'AQ0(\d{6})', file_name)
            if not device_id_match:
                logger.error(f"Could not extract Device_ID from {file_name}. Skipping.")
                continue
            
            device_id = int(device_id_match.group(1))  # Extract the 6-digit number after 'AQ0'
            if device_id not in DEVICE_COORDINATES:
                logger.warning(f"Device_ID {device_id} from {file_name} not in coordinates mapping. Geohash will be NaN.")
            
            df['Device_ID'] = device_id
            df['Geohash'] = df['Device_ID'].map(device_geohash)
            
            # Convert objects to numeric
            df.replace('-', pd.NA, inplace=True)
            for col in df.select_dtypes(include=['object']).columns:
                if col not in ['Time', 'Device_ID', 'Geohash']:
                    df[col] = pd.to_numeric(df[col], errors='coerce')
            
            # Validate key columns
            if 'PM2.5' in df.columns:
                invalid_pm25 = df[(df['PM2.5'] < 0) | (df['PM2.5'] > 500)].index
                df.loc[invalid_pm25, 'PM2.5'] = pd.NA
                if not invalid_pm25.empty:
                    logger.warning(f"{len(invalid_pm25)} rows with invalid PM2.5 values in {file_name}; set to NaN.")
            
            if 'Wind_Direction' in df.columns:
                invalid_wind = df[(df['Wind_Direction'] < 0) | (df['Wind_Direction'] > 360)].index
                df.loc[invalid_wind, 'Wind_Direction'] = pd.NA
                if not invalid_wind.empty:
                    logger.warning(f"{len(invalid_wind)} rows with invalid Wind_Direction values in {file_name}; set to NaN.")
            
            # Fill missing values for continuous variables
            for col in ['Temperature', 'Humidity', 'Wind_Speed']:
                if col in df.columns:
                    df[col] = df[col].ffill().bfill()
            
            # Fill calibration factors
            cf_columns = ['P1_CF', 'P2_CF', 'P3_CF', 'P4_CF', 'HUM_CF', 'TEMP_CF']
            for col in cf_columns:
                if col in df.columns:
                    df[col] = df[col].fillna(100.0)
            
            all_data.append(df)
        except Exception as e:
            logger.error(f"Error processing {uploaded_file.name}: {e}")
            continue
    
    if all_data:
        # Ensure consistent columns across all DataFrames
        for i in range(len(all_data)):
            missing_cols = all_columns - set(all_data[i].columns)
            for col in missing_cols:
                all_data[i][col] = pd.NA
        
        merged_df = pd.concat(all_data, ignore_index=True)
        merged_df.sort_values(by=['Device_ID', 'Datetime'], ascending=[True, True], inplace=True)
        return merged_df
    
    return None


def load_sample_data():
    """
    Generate sample air quality data for demonstration purposes.
    
    Returns:
        pandas.DataFrame: Sample air quality data
    """
    # Create sample data with realistic patterns
    devices = list(DEVICE_COORDINATES.keys())
    num_devices = len(devices)
    
    # Generate a date range for the past 7 days with hourly readings
    end_date = pd.Timestamp.now().floor('H')
    start_date = end_date - pd.Timedelta(days=7)
    dates = pd.date_range(start=start_date, end=end_date, freq='1H')
    
    # Create an empty list to hold all device data
    all_device_data = []
    
    # Create a mapping of device IDs to geohash
    device_geohash = {}
    for device_id, (lat, lon) in DEVICE_COORDINATES.items():
        try:
            # Make sure coordinates are properly formatted
            lat_float = float(lat)
            lon_float = float(lon)
            device_geohash[device_id] = geohash2.encode(lat_float, lon_float, precision=7)
        except Exception as e:
            logger.error(f"Error encoding geohash for device {device_id}: {e}")
            # Skip this device
    
    # Generate data for each device
    for device_id in devices:
        # Skip devices without valid geohash
        if device_id not in device_geohash:
            continue
            
        # Base values with some device-specific variation
        base_temp = 25 + np.random.uniform(-5, 5)
        base_humidity = 60 + np.random.uniform(-10, 10)
        base_pm25 = 30 + np.random.uniform(-10, 30)
        
        device_data = []
        
        for ts in dates:
            # Daily and hourly patterns
            hour = ts.hour
            day_of_week = ts.dayofweek
            
            # Temperature varies throughout the day (cooler at night, warmer in afternoon)
            temp_hourly_factor = -np.cos(hour/24 * 2 * np.pi) * 5
            temperature = base_temp + temp_hourly_factor + np.random.normal(0, 1)
            
            # Humidity is inverse to temperature
            humidity = base_humidity - temp_hourly_factor + np.random.normal(0, 5)
            humidity = max(min(humidity, 100), 0)  # Cap between 0-100%
            
            # PM2.5 is higher during rush hours and weekdays
            rush_hour_factor = 15 if (hour in [8, 9, 17, 18]) else 0
            weekday_factor = 10 if (day_of_week < 5) else 0
            pm25 = base_pm25 + rush_hour_factor + weekday_factor + np.random.normal(0, 5)
            pm25 = max(pm25, 0)  # No negative PM2.5
            
            # PM10 is correlated with PM2.5 but slightly higher
            pm10 = pm25 * 1.5 + np.random.normal(0, 5)
            
            # Wind speed and direction
            wind_speed = np.random.gamma(2, 1.5)
            wind_direction = np.random.uniform(0, 360)
            
            # Append to device data
            try:
                device_data.append({
                    'Datetime': ts,
                    'Time': ts.strftime('%H:%M:%S'),
                    'Device_ID': device_id,
                    'Temperature': temperature,
                    'Humidity': humidity,
                    'PM2.5': pm25,
                    'PM10': pm10,
                    'PM1': pm25 * 0.6 + np.random.normal(0, 2),
                    'PM100': pm10 * 1.2 + np.random.normal(0, 10),
                    'Wind_Speed': wind_speed,
                    'Wind_Direction': wind_direction,
                    'FAN': 1,
                    'P1_CF': 100.0,
                    'P2_CF': 100.0,
                    'P3_CF': 100.0,
                    'P4_CF': 100.0,
                    'HUM_CF': 100.0,
                    'TEMP_CF': 100.0,
                    'Geohash': device_geohash[device_id] # Use pre-computed geohash
                })
            except Exception as e:
                logger.error(f"Error generating sample data for device {device_id}: {e}")
                continue
        
        all_device_data.extend(device_data)
    
    # Convert to DataFrame
    df = pd.DataFrame(all_device_data)
    return df


def get_data_summary(df):
    """
    Generate a summary of the dataset.
    
    Args:
        df: pandas.DataFrame - The data to summarize
        
    Returns:
        dict: Summary statistics
    """
    if df is None or df.empty:
        return {}
    
    summary = {
        'total_records': len(df),
        'date_range': (df['Datetime'].min(), df['Datetime'].max()),
        'devices': df['Device_ID'].nunique(),
        'metrics': {}
    }
    
    # Get summary for key metrics
    key_metrics = ['PM2.5', 'PM10', 'Temperature', 'Humidity', 'Wind_Speed']
    for metric in key_metrics:
        if metric in df.columns:
            summary['metrics'][metric] = {
                'mean': df[metric].mean(),
                'median': df[metric].median(),
                'min': df[metric].min(),
                'max': df[metric].max(),
                'std': df[metric].std()
            }
    
    return summary


def calculate_aqi(df):
    """
    Calculate Air Quality Index based on PM2.5 levels.
    
    Args:
        df: pandas.DataFrame with PM2.5 values
        
    Returns:
        pandas.DataFrame with AQI column added
    """
    if df is None or df.empty or 'PM2.5' not in df.columns:
        return df
    
    result_df = df.copy()
    
    # Define AQI breakpoints and corresponding PM2.5 ranges
    pm25_ranges = [
        (0, 12, 0, 50, 'Good'),
        (12.1, 35.4, 51, 100, 'Moderate'),
        (35.5, 55.4, 101, 150, 'Unhealthy for Sensitive Groups'),
        (55.5, 150.4, 151, 200, 'Unhealthy'),
        (150.5, 250.4, 201, 300, 'Very Unhealthy'),
        (250.5, 500.4, 301, 500, 'Hazardous')
    ]
    
    # Function to calculate AQI for a PM2.5 value
    def get_aqi_and_category(pm25):
        if pd.isna(pm25):
            return pd.NA, "Unknown"
        
        for low_pm25, high_pm25, low_aqi, high_aqi, category in pm25_ranges:
            if low_pm25 <= pm25 <= high_pm25:
                aqi = ((high_aqi - low_aqi) / (high_pm25 - low_pm25)) * (pm25 - low_pm25) + low_aqi
                return round(aqi), category
        
        # If PM2.5 is above the highest range
        if pm25 > 500.4:
            return 500, "Hazardous"
        # If PM2.5 is below the lowest range (shouldn't happen, but just in case)
        return 0, "Good"
    
    # Apply the function to calculate AQI and category
    result = result_df['PM2.5'].apply(lambda x: pd.Series(get_aqi_and_category(x), index=['AQI', 'AQI_Category']))
    result_df = pd.concat([result_df, result], axis=1)
    
    return result_df
