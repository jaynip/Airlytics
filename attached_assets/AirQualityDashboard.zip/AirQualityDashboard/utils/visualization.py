import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import streamlit as st

def create_correlation_heatmap(df):
    """
    Create a correlation heatmap for key variables.
    
    Args:
        df: pandas.DataFrame - The data to visualize
        
    Returns:
        plotly.graph_objects.Figure: Correlation heatmap
    """
    if df is None or df.empty:
        return go.Figure()
    
    key_columns = ['PM2.5', 'PM10', 'PM1', 'Temperature', 'Humidity', 'Wind_Speed', 'Wind_Direction']
    available_columns = [col for col in key_columns if col in df.columns]
    
    if len(available_columns) < 2:
        fig = go.Figure()
        fig.add_annotation(
            text="Insufficient data for correlation analysis",
            xref="paper", yref="paper",
            x=0.5, y=0.5, showarrow=False
        )
        return fig
    
    df_clean = df[available_columns].copy()
    
    # Fill NaN with mean instead of dropping
    for col in df_clean.columns:
        df_clean[col] = df_clean[col].fillna(df_clean[col].mean())
    
    correlation_matrix = df_clean.corr()
    
    # Create heatmap
    fig = px.imshow(
        correlation_matrix,
        text_auto=True,
        aspect="auto",
        color_continuous_scale="RdBu_r",
        zmin=-1, zmax=1,
        title="Correlation Matrix of Key Environmental Variables"
    )
    
    fig.update_layout(
        height=600,
        margin=dict(l=20, r=20, t=40, b=20),
        coloraxis_colorbar=dict(
            title="Correlation",
            thicknessmode="pixels", thickness=20,
            lenmode="pixels", len=400,
            yanchor="top", y=1,
            ticks="outside"
        )
    )
    
    return fig

def plot_time_series(df, metrics=None, device_ids=None):
    """
    Create time series plots for selected metrics.
    
    Args:
        df: pandas.DataFrame - The data to visualize
        metrics: list - Metrics to plot (default: PM2.5, PM10, Temperature)
        device_ids: list - Device IDs to include (default: all devices)
        
    Returns:
        plotly.graph_objects.Figure: Time series plot
    """
    if df is None or df.empty or 'Datetime' not in df.columns:
        return go.Figure()
    
    if metrics is None:
        default_metrics = ['PM2.5', 'PM10', 'Temperature']
        metrics = [m for m in default_metrics if m in df.columns]
        if not metrics:  # If none of the default metrics are available
            metrics = [col for col in df.columns if col not in ['Datetime', 'Device_ID', 'Time', 'Geohash']][:3]
    
    # Filter by device IDs if provided
    plot_df = df.copy()
    if device_ids is not None and 'Device_ID' in df.columns:
        plot_df = plot_df[plot_df['Device_ID'].isin(device_ids)]
    
    # Create figure with secondary y-axis
    fig = make_subplots(specs=[[{"secondary_y": True}]])
    
    # Add traces for each metric and device
    for i, metric in enumerate(metrics):
        if metric not in plot_df.columns:
            continue
        
        if 'Device_ID' in plot_df.columns:
            for device_id in plot_df['Device_ID'].unique():
                device_df = plot_df[plot_df['Device_ID'] == device_id]
                
                # Use secondary y-axis for temperature and humidity
                use_secondary = metric in ['Temperature', 'Humidity']
                
                fig.add_trace(
                    go.Scatter(
                        x=device_df['Datetime'],
                        y=device_df[metric],
                        mode='lines',
                        name=f"{metric} (Device {device_id})",
                        line=dict(width=2)
                    ),
                    secondary_y=use_secondary
                )
        else:
            # If no Device_ID column, just plot the metric
            use_secondary = metric in ['Temperature', 'Humidity']
            
            fig.add_trace(
                go.Scatter(
                    x=plot_df['Datetime'],
                    y=plot_df[metric],
                    mode='lines',
                    name=metric,
                    line=dict(width=2)
                ),
                secondary_y=use_secondary
            )
    
    # Update layout and axis labels
    fig.update_layout(
        title="Time Series Analysis of Air Quality Metrics",
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="right",
            x=1
        ),
        margin=dict(l=20, r=20, t=40, b=20),
        height=500
    )
    
    # Set y-axes titles
    pm_metrics = [m for m in metrics if 'PM' in m]
    other_metrics = [m for m in metrics if 'PM' not in m and m in ['Temperature', 'Humidity']]
    
    if pm_metrics:
        pm_title = "Particulate Matter (µg/m³)"
        fig.update_yaxes(title_text=pm_title, secondary_y=False)
    
    if other_metrics:
        if 'Temperature' in other_metrics and 'Humidity' in other_metrics:
            other_title = "Temperature (°C) / Humidity (%)"
        elif 'Temperature' in other_metrics:
            other_title = "Temperature (°C)"
        else:
            other_title = "Humidity (%)"
        fig.update_yaxes(title_text=other_title, secondary_y=True)
    
    return fig

def create_daily_pattern_chart(df, metric='PM2.5'):
    """
    Create a chart showing daily patterns for a given metric.
    
    Args:
        df: pandas.DataFrame - The data to visualize
        metric: str - Metric to analyze (default: PM2.5)
        
    Returns:
        plotly.graph_objects.Figure: Daily pattern chart
    """
    if df is None or df.empty or metric not in df.columns or 'Datetime' not in df.columns:
        return go.Figure()
    
    # Extract hour of day
    plot_df = df.copy()
    plot_df['Hour'] = pd.to_datetime(plot_df['Datetime']).dt.hour
    
    # Group by hour and calculate statistics
    hourly_stats = plot_df.groupby('Hour')[metric].agg(['mean', 'median', 'std']).reset_index()
    
    # Create figure
    fig = go.Figure()
    
    # Add mean line
    fig.add_trace(go.Scatter(
        x=hourly_stats['Hour'],
        y=hourly_stats['mean'],
        mode='lines+markers',
        name='Mean',
        line=dict(color='blue', width=2),
        marker=dict(size=8)
    ))
    
    # Add range (mean ± std)
    fig.add_trace(go.Scatter(
        x=hourly_stats['Hour'],
        y=hourly_stats['mean'] + hourly_stats['std'],
        mode='lines',
        name='Mean + Std Dev',
        line=dict(color='rgba(0,0,255,0.2)', width=0)
    ))
    
    fig.add_trace(go.Scatter(
        x=hourly_stats['Hour'],
        y=hourly_stats['mean'] - hourly_stats['std'],
        mode='lines',
        name='Mean - Std Dev',
        line=dict(color='rgba(0,0,255,0.2)', width=0),
        fill='tonexty'
    ))
    
    # Update layout
    fig.update_layout(
        title=f"Daily Pattern of {metric}",
        xaxis_title="Hour of Day",
        yaxis_title=f"{metric} Value",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        xaxis=dict(tickmode='linear', tick0=0, dtick=1),
        height=400
    )
    
    return fig

def create_pollutant_rose(df, pollutant='PM2.5'):
    """
    Create a pollution rose chart showing pollutant levels by wind direction.
    
    Args:
        df: pandas.DataFrame - The data to visualize
        pollutant: str - Pollutant to analyze (default: PM2.5)
        
    Returns:
        plotly.graph_objects.Figure: Pollution rose chart
    """
    if (df is None or df.empty or 
        pollutant not in df.columns or 
        'Wind_Direction' not in df.columns or
        df['Wind_Direction'].isna().all()):
        return go.Figure()
    
    # Create bins for wind direction (0-360 degrees in 30-degree bins)
    df_clean = df.dropna(subset=['Wind_Direction', pollutant]).copy()
    df_clean['Wind_Direction_Bin'] = ((df_clean['Wind_Direction'] % 360) // 30) * 30
    
    # Group by wind direction bin and calculate mean pollutant level
    wind_dir_stats = df_clean.groupby('Wind_Direction_Bin')[pollutant].mean().reset_index()
    
    # Add 360 degrees to complete the circle
    wind_dir_stats = pd.concat([
        wind_dir_stats, 
        pd.DataFrame({
            'Wind_Direction_Bin': [360], 
            pollutant: [wind_dir_stats.loc[wind_dir_stats['Wind_Direction_Bin'] == 0, pollutant].values[0]]
        })
    ])
    
    # Create the figure
    fig = go.Figure()
    
    fig.add_trace(go.Scatterpolar(
        r=wind_dir_stats[pollutant],
        theta=wind_dir_stats['Wind_Direction_Bin'],
        mode='lines+markers',
        name=pollutant,
        line=dict(color='#4bb051', width=2),
        marker=dict(size=8)
    ))
    
    # Update layout
    fig.update_layout(
        title=f"{pollutant} Levels by Wind Direction",
        polar=dict(
            radialaxis=dict(
                visible=True,
                title=f"{pollutant} Level"
            ),
            angularaxis=dict(
                visible=True,
                type='linear',
                direction='clockwise',
                tickmode='array',
                tickvals=[0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 330],
                ticktext=['N', 'NNE', 'ENE', 'E', 'ESE', 'SSE', 'S', 'SSW', 'WSW', 'W', 'WNW', 'NNW']
            )
        ),
        height=500
    )
    
    return fig

def create_aqi_distribution(df):
    """
    Create an AQI distribution chart showing percentage of time in each AQI category.
    
    Args:
        df: pandas.DataFrame - The data with AQI_Category column
        
    Returns:
        plotly.graph_objects.Figure: AQI distribution chart
    """
    if df is None or df.empty or 'AQI_Category' not in df.columns:
        return go.Figure()
    
    # Category order
    category_order = [
        'Good', 
        'Moderate', 
        'Unhealthy for Sensitive Groups', 
        'Unhealthy', 
        'Very Unhealthy', 
        'Hazardous'
    ]
    
    # Colors for each category
    category_colors = {
        'Good': '#00e400',
        'Moderate': '#ffff00',
        'Unhealthy for Sensitive Groups': '#ff7e00',
        'Unhealthy': '#ff0000',
        'Very Unhealthy': '#99004c',
        'Hazardous': '#7e0023',
        'Unknown': '#cccccc'
    }
    
    # Count occurrences of each category
    category_counts = df['AQI_Category'].value_counts().reset_index()
    category_counts.columns = ['AQI_Category', 'Count']
    
    # Calculate percentages
    total = category_counts['Count'].sum()
    category_counts['Percentage'] = (category_counts['Count'] / total) * 100
    
    # Sort by category order
    category_counts['order'] = category_counts['AQI_Category'].map(
        {cat: i for i, cat in enumerate(category_order + ['Unknown'])}
    )
    category_counts = category_counts.sort_values('order')
    
    # Get colors for each category
    colors = [category_colors.get(cat, '#cccccc') for cat in category_counts['AQI_Category']]
    
    # Create bar chart
    fig = go.Figure()
    
    fig.add_trace(go.Bar(
        x=category_counts['AQI_Category'],
        y=category_counts['Percentage'],
        marker_color=colors,
        text=[f'{p:.1f}%' for p in category_counts['Percentage']],
        textposition='auto'
    ))
    
    # Update layout
    fig.update_layout(
        title="Distribution of Air Quality Index Categories",
        xaxis_title="AQI Category",
        yaxis_title="Percentage of Time (%)",
        height=400
    )
    
    return fig

def create_device_comparison_chart(df, metric='PM2.5'):
    """
    Create a chart comparing a metric across different devices.
    
    Args:
        df: pandas.DataFrame - The data to visualize
        metric: str - Metric to compare (default: PM2.5)
        
    Returns:
        plotly.graph_objects.Figure: Device comparison chart
    """
    if df is None or df.empty or metric not in df.columns or 'Device_ID' not in df.columns:
        return go.Figure()
    
    # Group by device and calculate statistics
    device_stats = df.groupby('Device_ID')[metric].agg(['mean', 'median', 'min', 'max']).reset_index()
    
    # Create figure
    fig = go.Figure()
    
    # Add box plot
    for device_id in device_stats['Device_ID']:
        device_data = df[df['Device_ID'] == device_id][metric].dropna()
        
        fig.add_trace(go.Box(
            y=device_data,
            name=str(device_id),
            boxmean=True
        ))
    
    # Update layout
    fig.update_layout(
        title=f"Comparison of {metric} Across Devices",
        xaxis_title="Device ID",
        yaxis_title=f"{metric} Value",
        height=500
    )
    
    return fig
