import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
import geohash2
import logging

logger = logging.getLogger(__name__)

# Device coordinates mapping (latitude, longitude)
DEVICE_COORDINATES = {
    523005: (23.02909505, 72.49078965),
    523011: (23.0309101, 72.5088321),
    523047: (23.0692036, 72.5653925),
    523082: (23.0850114, 72.5751516),
    523093: (23.096915, 72.527362),
    524037: (23.04836488, 72.68863108),
    524046: (23.0428964, 72.4749039),
    524049: (23.0777287, 72.5056656),
    524062: (23.12348122, 72.53853052),
    524089: (23.02815923, 72.50001528),
    524091: (23.0087287, 72.4551301),
}

def decode_geohash(geohash):
    """Decode geohash to latitude and longitude"""
    try:
        lat, lon = geohash2.decode(geohash)
        return float(lat), float(lon)
    except Exception as e:
        logger.error(f"Error decoding geohash {geohash}: {str(e)}")
        return None, None

def render_map_view(df):
    """
    Render a geospatial map view of air quality data.
    
    Args:
        df: pandas.DataFrame - The data to visualize
    """
    st.header("Geospatial Analysis")
    
    if df is None or df.empty:
        st.warning("No data available to display. Please upload data files or load sample data.")
        return
    
    # Check if geospatial data is available
    if 'Geohash' not in df.columns:
        st.error("Geospatial data (Geohash) not available in the dataset.")
        return
    
    # Controls
    st.subheader("Map Controls")
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Metric selection for color coding
        available_metrics = [
            col for col in df.columns 
            if col not in ['Datetime', 'Time', 'Device_ID', 'Geohash'] 
            and df[col].dtype in ['float64', 'int64']
        ]
        
        selected_metric = st.selectbox(
            "Color Map by Metric",
            options=available_metrics,
            index=available_metrics.index('PM2.5') if 'PM2.5' in available_metrics else 0
        )
    
    with col2:
        # Time aggregation
        time_options = ["Latest", "Average", "Maximum"]
        time_agg = st.selectbox(
            "Time Aggregation",
            options=time_options,
            index=0
        )
    
    # Process data for mapping
    map_df = prepare_map_data(df, selected_metric, time_agg)
    
    if map_df is None or map_df.empty:
        st.error("Could not prepare map data. Please check that coordinates are available.")
        return
    
    # Create the map
    st.subheader(f"Air Quality Map ({selected_metric})")
    fig = create_map(map_df, selected_metric)
    st.plotly_chart(fig, use_container_width=True)
    
    # Device location table
    st.subheader("Device Locations")
    devices_df = pd.DataFrame([
        {"Device ID": device_id, "Latitude": lat, "Longitude": lon}
        for device_id, (lat, lon) in DEVICE_COORDINATES.items()
    ])
    st.dataframe(devices_df)
    
    # Time animation option
    st.subheader("Time Series Animation")
    if 'Datetime' in df.columns:
        show_animation = st.checkbox("Show time-based animation")
        
        if show_animation:
            # Sample data for animation (using daily averages to reduce data size)
            anim_df = prepare_animation_data(df, selected_metric)
            
            fig_anim = create_animated_map(anim_df, selected_metric)
            st.plotly_chart(fig_anim, use_container_width=True)
    else:
        st.info("Datetime information not available for animation.")

def prepare_map_data(df, metric, time_agg):
    """
    Prepare data for mapping by aggregating based on device and time.
    
    Args:
        df: pandas.DataFrame - The original data
        metric: str - Metric to visualize
        time_agg: str - Time aggregation method
        
    Returns:
        pandas.DataFrame - Processed data for mapping
    """
    if metric not in df.columns:
        return None
    
    # Create a copy to avoid modifying the original
    map_df = df.copy()
    
    # Add lat/lon from geohash or device ID
    if 'Geohash' in map_df.columns and not map_df['Geohash'].isna().all():
        # Decode geohash to get coordinates
        coords = map_df['Geohash'].apply(decode_geohash)
        map_df['Latitude'] = coords.apply(lambda x: x[0])
        map_df['Longitude'] = coords.apply(lambda x: x[1])
    elif 'Device_ID' in map_df.columns:
        # Use device ID to lookup coordinates
        map_df['Latitude'] = map_df['Device_ID'].map(lambda x: DEVICE_COORDINATES.get(x, (None, None))[0])
        map_df['Longitude'] = map_df['Device_ID'].map(lambda x: DEVICE_COORDINATES.get(x, (None, None))[1])
    else:
        return None
    
    # Drop rows with missing coordinates
    map_df = map_df.dropna(subset=['Latitude', 'Longitude'])
    
    # Aggregate based on time_agg parameter
    if 'Device_ID' in map_df.columns:
        if time_agg == "Latest" and 'Datetime' in map_df.columns:
            # Get the latest reading for each device
            latest_idx = map_df.groupby('Device_ID')['Datetime'].idxmax()
            map_df = map_df.loc[latest_idx]
        elif time_agg == "Average":
            # Get average for each device
            map_df = map_df.groupby('Device_ID').agg({
                'Latitude': 'first',
                'Longitude': 'first',
                metric: 'mean',
                'Geohash': 'first'
            }).reset_index()
        elif time_agg == "Maximum":
            # Get maximum for each device
            map_df = map_df.groupby('Device_ID').agg({
                'Latitude': 'first',
                'Longitude': 'first',
                metric: 'max',
                'Geohash': 'first'
            }).reset_index()
    
    return map_df

def create_map(df, metric):
    """
    Create a map visualization of air quality data.
    
    Args:
        df: pandas.DataFrame - The data to visualize
        metric: str - Metric to visualize
        
    Returns:
        plotly.graph_objects.Figure - Map figure
    """
    # Color scale based on metric
    if metric.startswith('PM'):
        color_scale = [
            [0, 'green'],     # Good
            [0.2, 'yellow'],  # Moderate
            [0.4, 'orange'],  # Unhealthy for Sensitive Groups
            [0.6, 'red'],     # Unhealthy
            [0.8, 'purple'],  # Very Unhealthy
            [1.0, 'maroon']   # Hazardous
        ]
    else:
        color_scale = 'Viridis'
    
    # Create the map
    fig = px.scatter_mapbox(
        df,
        lat='Latitude',
        lon='Longitude',
        color=metric,
        size=metric,
        size_max=15,
        zoom=10,
        color_continuous_scale=color_scale,
        hover_name='Device_ID' if 'Device_ID' in df.columns else None,
        hover_data={
            'Latitude': False,
            'Longitude': False,
            metric: True,
            'Device_ID': True if 'Device_ID' in df.columns else False
        },
        title=f"Air Quality Map - {metric}"
    )
    
    fig.update_layout(
        mapbox_style="open-street-map",
        height=600,
        margin=dict(l=0, r=0, t=40, b=0),
    )
    
    return fig

def create_simple_map(df):
    """
    Create a simplified map for dashboard preview.
    
    Args:
        df: pandas.DataFrame - The data to visualize
        
    Returns:
        plotly.graph_objects.Figure - Simplified map
    """
    # Prepare data
    if 'PM2.5' in df.columns:
        metric = 'PM2.5'
    elif 'PM10' in df.columns:
        metric = 'PM10'
    else:
        # Use first numeric column
        numeric_cols = df.select_dtypes(include=['float64', 'int64']).columns
        if not numeric_cols.empty:
            metric = numeric_cols[0]
        else:
            # Create empty figure if no suitable metric
            fig = go.Figure()
            fig.update_layout(
                title="No suitable metrics for mapping",
                height=300
            )
            return fig
    
    # Get simplified map data
    map_df = prepare_map_data(df, metric, "Average")
    
    if map_df is None or map_df.empty:
        fig = go.Figure()
        fig.update_layout(
            title="Could not prepare map data",
            height=300
        )
        return fig
    
    # Create simple map
    fig = px.scatter_mapbox(
        map_df,
        lat='Latitude',
        lon='Longitude',
        color=metric,
        size=metric,
        size_max=10,
        zoom=9,
        hover_name='Device_ID' if 'Device_ID' in map_df.columns else None,
    )
    
    fig.update_layout(
        mapbox_style="open-street-map",
        height=300,
        margin=dict(l=0, r=0, t=30, b=0),
    )
    
    return fig

def prepare_animation_data(df, metric):
    """
    Prepare data for animated time series map.
    
    Args:
        df: pandas.DataFrame - The original data
        metric: str - Metric to visualize
        
    Returns:
        pandas.DataFrame - Processed data for animation
    """
    if 'Datetime' not in df.columns or metric not in df.columns:
        return None
    
    # Create a copy to avoid modifying the original
    anim_df = df.copy()
    
    # Add lat/lon from geohash or device ID
    if 'Geohash' in anim_df.columns and not anim_df['Geohash'].isna().all():
        # Decode geohash to get coordinates
        coords = anim_df['Geohash'].apply(decode_geohash)
        anim_df['Latitude'] = coords.apply(lambda x: x[0])
        anim_df['Longitude'] = coords.apply(lambda x: x[1])
    elif 'Device_ID' in anim_df.columns:
        # Use device ID to lookup coordinates
        anim_df['Latitude'] = anim_df['Device_ID'].map(lambda x: DEVICE_COORDINATES.get(x, (None, None))[0])
        anim_df['Longitude'] = anim_df['Device_ID'].map(lambda x: DEVICE_COORDINATES.get(x, (None, None))[1])
    else:
        return None
    
    # Drop rows with missing coordinates
    anim_df = anim_df.dropna(subset=['Latitude', 'Longitude'])
    
    # Convert datetime to date string for animation
    anim_df['Date'] = pd.to_datetime(anim_df['Datetime']).dt.strftime('%Y-%m-%d')
    
    # Aggregate to daily averages by device to reduce data size
    anim_df = anim_df.groupby(['Device_ID', 'Date']).agg({
        'Latitude': 'first',
        'Longitude': 'first',
        metric: 'mean'
    }).reset_index()
    
    return anim_df

def create_animated_map(df, metric):
    """
    Create an animated map visualization over time.
    
    Args:
        df: pandas.DataFrame - The data to visualize
        metric: str - Metric to visualize
        
    Returns:
        plotly.graph_objects.Figure - Animated map figure
    """
    if df is None or df.empty or 'Date' not in df.columns:
        fig = go.Figure()
        fig.update_layout(
            title="Insufficient data for animation",
            height=600
        )
        return fig
    
    # Color scale based on metric
    if metric.startswith('PM'):
        color_scale = [
            [0, 'green'],     # Good
            [0.2, 'yellow'],  # Moderate
            [0.4, 'orange'],  # Unhealthy for Sensitive Groups
            [0.6, 'red'],     # Unhealthy
            [0.8, 'purple'],  # Very Unhealthy
            [1.0, 'maroon']   # Hazardous
        ]
    else:
        color_scale = 'Viridis'
    
    # Create animated map
    fig = px.scatter_mapbox(
        df,
        lat='Latitude',
        lon='Longitude',
        color=metric,
        size=metric,
        size_max=15,
        animation_frame='Date',
        zoom=10,
        color_continuous_scale=color_scale,
        hover_name='Device_ID' if 'Device_ID' in df.columns else None,
        hover_data={
            'Latitude': False,
            'Longitude': False,
            metric: True,
            'Device_ID': True if 'Device_ID' in df.columns else False
        },
        title=f"Air Quality Time Animation - {metric}"
    )
    
    fig.update_layout(
        mapbox_style="open-street-map",
        height=600,
        margin=dict(l=0, r=0, t=40, b=0),
    )
    
    return fig
