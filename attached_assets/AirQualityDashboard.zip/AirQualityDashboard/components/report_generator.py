import streamlit as st
import pandas as pd
import numpy as np
import base64
import io
from datetime import datetime
import plotly.io as pio
import logging

# Set up logging
logger = logging.getLogger(__name__)
from utils.visualization import (
    create_correlation_heatmap,
    plot_time_series,
    create_daily_pattern_chart,
    create_pollutant_rose,
    create_aqi_distribution
)
from utils.data_processor import calculate_aqi, get_data_summary

def generate_report(df, ai_recommendations):
    """
    Generate a comprehensive report of air quality data.
    
    Args:
        df: pandas.DataFrame - The data to include in the report
        ai_recommendations: str - AI-generated recommendations
    """
    st.header("Air Quality Analysis Report Generator")
    
    if df is None or df.empty:
        st.warning("No data available to generate a report. Please upload data files or load sample data.")
        return
    
    # Calculate AQI if not already present
    if 'AQI' not in df.columns:
        df = calculate_aqi(df)
    
    # Report customization options
    st.subheader("Report Customization")
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Report title
        report_title = st.text_input(
            "Report Title", 
            value="Air Quality Analysis Report"
        )
        
        # Include sections
        st.write("Sections to Include:")
        include_summary = st.checkbox("Data Summary", value=True)
        include_time_series = st.checkbox("Time Series Analysis", value=True)
        include_correlations = st.checkbox("Correlation Analysis", value=True)
        include_air_quality = st.checkbox("Air Quality Index Analysis", value=True)
        include_recommendations = st.checkbox("AI Recommendations", value=True)
    
    with col2:
        # Report metadata
        report_date = st.date_input(
            "Report Date",
            value=datetime.now().date()
        )
        
        author = st.text_input(
            "Author/Organization",
            value="Air Quality Analytics Team"
        )
        
        # Time range in the data
        if 'Datetime' in df.columns:
            min_date = pd.to_datetime(df['Datetime']).min().date()
            max_date = pd.to_datetime(df['Datetime']).max().date()
            st.write(f"Data Time Range: {min_date} to {max_date}")
    
    # Report generation button
    if st.button("Generate Report"):
        with st.spinner("Generating report..."):
            try:
                # Generate PDF using HTML
                report_html = generate_report_html(
                    df, 
                    report_title, 
                    report_date,
                    author,
                    ai_recommendations,
                    include_summary,
                    include_time_series,
                    include_correlations,
                    include_air_quality,
                    include_recommendations
                )
                
                # Convert HTML to PDF-like report
                pdf_data = html_to_pdf(report_html)
                
                # Create download button
                st.download_button(
                    label="Download Report",
                    data=pdf_data,
                    file_name=f"air_quality_report_{report_date}.html",
                    mime="text/html"
                )
                
                # Preview
                st.subheader("Report Preview")
                st.components.v1.html(report_html, height=600, scrolling=True)
                
            except Exception as e:
                st.error(f"Error generating report: {str(e)}")

def generate_report_html(df, title, date, author, ai_recommendations,
                         include_summary, include_time_series, 
                         include_correlations, include_air_quality,
                         include_recommendations):
    """
    Generate an HTML report with the selected sections.
    
    Returns:
        str: HTML content of the report
    """
    # Start HTML content
    html = f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>{title}</title>
        <style>
            body {{
                font-family: Arial, sans-serif;
                line-height: 1.6;
                color: #333;
                max-width: 1200px;
                margin: 0 auto;
                padding: 20px;
            }}
            .header {{
                text-align: center;
                margin-bottom: 30px;
                padding-bottom: 20px;
                border-bottom: 1px solid #ddd;
            }}
            .header h1 {{
                color: #4bb051;
                margin-bottom: 10px;
            }}
            .metadata {{
                color: #666;
                font-style: italic;
            }}
            .section {{
                margin-bottom: 30px;
            }}
            .section h2 {{
                color: #4bb051;
                border-bottom: 1px solid #eee;
                padding-bottom: 10px;
            }}
            table {{
                width: 100%;
                border-collapse: collapse;
                margin-bottom: 20px;
            }}
            th, td {{
                padding: 10px;
                border: 1px solid #ddd;
                text-align: left;
            }}
            th {{
                background-color: #f5f5f5;
            }}
            .figure {{
                margin: 20px 0;
                text-align: center;
            }}
            .figure img {{
                max-width: 100%;
                height: auto;
                border: 1px solid #ddd;
            }}
            .caption {{
                font-style: italic;
                color: #666;
                margin-top: 10px;
            }}
            .recommendations {{
                background-color: #f9f9f9;
                padding: 15px;
                border-left: 4px solid #4bb051;
                margin-bottom: 20px;
            }}
            footer {{
                margin-top: 50px;
                padding-top: 20px;
                border-top: 1px solid #ddd;
                text-align: center;
                font-size: 0.9em;
                color: #666;
            }}
        </style>
    </head>
    <body>
        <div class="header">
            <h1>{title}</h1>
            <div class="metadata">
                <p>Generated on: {date} | Author: {author}</p>
            </div>
        </div>
    """
    
    # Data Summary Section
    if include_summary:
        html += """
        <div class="section">
            <h2>Data Summary</h2>
        """
        
        # Dataset overview
        summary = get_data_summary(df)
        html += f"""
            <h3>Dataset Overview</h3>
            <p>This report analyzes air quality data collected from {summary.get('devices', 'multiple')} 
            devices, comprising {summary.get('total_records', 'numerous')} measurements.</p>
        """
        
        # Date range
        if 'date_range' in summary and summary['date_range']:
            start_date, end_date = summary['date_range']
            html += f"""
            <p>Time Range: {start_date} to {end_date}</p>
            """
        
        # Key metrics summary table
        if 'metrics' in summary and summary['metrics']:
            html += """
            <h3>Key Metrics Summary</h3>
            <table>
                <tr>
                    <th>Metric</th>
                    <th>Mean</th>
                    <th>Median</th>
                    <th>Min</th>
                    <th>Max</th>
                    <th>Std. Dev.</th>
                </tr>
            """
            
            for metric, stats in summary['metrics'].items():
                html += f"""
                <tr>
                    <td>{metric}</td>
                    <td>{stats['mean']:.2f}</td>
                    <td>{stats['median']:.2f}</td>
                    <td>{stats['min']:.2f}</td>
                    <td>{stats['max']:.2f}</td>
                    <td>{stats['std']:.2f}</td>
                </tr>
                """
            
            html += """
            </table>
            """
        
        html += """
        </div>
        """
    
    # Time Series Analysis Section
    if include_time_series:
        html += """
        <div class="section">
            <h2>Time Series Analysis</h2>
        """
        
        # Time series plot for PM2.5 and PM10
        if 'PM2.5' in df.columns or 'PM10' in df.columns:
            metrics = []
            if 'PM2.5' in df.columns:
                metrics.append('PM2.5')
            if 'PM10' in df.columns:
                metrics.append('PM10')
            
            fig = plot_time_series(df, metrics=metrics)
            
            try:
                # Try to convert to image, but fallback to JSON if kaleido not available
                img_bytes = pio.to_image(fig, format='png')
                img_base64 = base64.b64encode(img_bytes).decode('ascii')
                
                html += f"""
                <div class="figure">
                    <img src="data:image/png;base64,{img_base64}" alt="Time Series Analysis">
                    <div class="caption">Figure 1: Time Series Analysis of Key Pollutants</div>
                </div>
                """
            except Exception as e:
                logger.warning(f"Could not generate image due to: {str(e)}. Embedding interactive plot.")
                # Embed interactive plot
                fig_json = fig.to_json()
                html += f"""
                <div class="figure">
                    <div id="plotly-time-series" style="width:100%;height:400px;"></div>
                    <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
                    <script>
                        var plotlyData = {fig_json};
                        Plotly.newPlot('plotly-time-series', plotlyData.data, plotlyData.layout);
                    </script>
                    <div class="caption">Figure 1: Time Series Analysis of Key Pollutants</div>
                </div>
                """
        
        # Daily patterns
        if 'PM2.5' in df.columns:
            fig = create_daily_pattern_chart(df, metric='PM2.5')
            
            try:
                img_bytes = pio.to_image(fig, format='png')
                img_base64 = base64.b64encode(img_bytes).decode('ascii')
                
                html += f"""
                <div class="figure">
                    <img src="data:image/png;base64,{img_base64}" alt="Daily Pattern Analysis">
                    <div class="caption">Figure 2: Daily Pattern of PM2.5 Levels</div>
                </div>
                """
            except Exception as e:
                logger.warning(f"Could not generate image due to: {str(e)}. Embedding interactive plot.")
                fig_json = fig.to_json()
                html += f"""
                <div class="figure">
                    <div id="plotly-daily-pattern" style="width:100%;height:400px;"></div>
                    <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
                    <script>
                        var dailyPatternData = {fig_json};
                        Plotly.newPlot('plotly-daily-pattern', dailyPatternData.data, dailyPatternData.layout);
                    </script>
                    <div class="caption">Figure 2: Daily Pattern of PM2.5 Levels</div>
                </div>
                """
        
        html += """
        </div>
        """
    
    # Correlation Analysis Section
    if include_correlations:
        html += """
        <div class="section">
            <h2>Correlation Analysis</h2>
        """
        
        # Correlation heatmap
        fig = create_correlation_heatmap(df)
        
        try:
            img_bytes = pio.to_image(fig, format='png')
            img_base64 = base64.b64encode(img_bytes).decode('ascii')
            
            html += f"""
            <div class="figure">
                <img src="data:image/png;base64,{img_base64}" alt="Correlation Heatmap">
                <div class="caption">Figure 3: Correlation Matrix of Key Environmental Variables</div>
            </div>
            """
        except Exception as e:
            logger.warning(f"Could not generate image due to: {str(e)}. Embedding interactive plot.")
            fig_json = fig.to_json()
            html += f"""
            <div class="figure">
                <div id="plotly-correlation" style="width:100%;height:400px;"></div>
                <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
                <script>
                    var corrData = {fig_json};
                    Plotly.newPlot('plotly-correlation', corrData.data, corrData.layout);
                </script>
                <div class="caption">Figure 3: Correlation Matrix of Key Environmental Variables</div>
            </div>
            """
            
        html += """
        <p>
            This correlation matrix shows the relationships between different environmental variables. 
            Positive correlations (closer to 1) indicate that variables tend to increase together, 
            while negative correlations (closer to -1) indicate that as one variable increases, the other decreases.
        </p>
        """
        
        # Pollutant rose if available
        if 'PM2.5' in df.columns and 'Wind_Direction' in df.columns:
            fig = create_pollutant_rose(df, pollutant='PM2.5')
            
            try:
                img_bytes = pio.to_image(fig, format='png')
                img_base64 = base64.b64encode(img_bytes).decode('ascii')
                
                html += f"""
                <div class="figure">
                    <img src="data:image/png;base64,{img_base64}" alt="Pollutant Rose">
                    <div class="caption">Figure 4: PM2.5 Levels by Wind Direction</div>
                </div>
                """
            except Exception as e:
                logger.warning(f"Could not generate image due to: {str(e)}. Embedding interactive plot.")
                fig_json = fig.to_json()
                html += f"""
                <div class="figure">
                    <div id="plotly-rose" style="width:100%;height:400px;"></div>
                    <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
                    <script>
                        var roseData = {fig_json};
                        Plotly.newPlot('plotly-rose', roseData.data, roseData.layout);
                    </script>
                    <div class="caption">Figure 4: PM2.5 Levels by Wind Direction</div>
                </div>
                """
        
        html += """
        </div>
        """
    
    # Air Quality Index Analysis
    if include_air_quality and 'AQI' in df.columns and 'AQI_Category' in df.columns:
        html += """
        <div class="section">
            <h2>Air Quality Index Analysis</h2>
        """
        
        # AQI distribution
        fig = create_aqi_distribution(df)
        
        try:
            img_bytes = pio.to_image(fig, format='png')
            img_base64 = base64.b64encode(img_bytes).decode('ascii')
            
            html += f"""
            <div class="figure">
                <img src="data:image/png;base64,{img_base64}" alt="AQI Distribution">
                <div class="caption">Figure 5: Distribution of Air Quality Index Categories</div>
            </div>
            """
        except Exception as e:
            logger.warning(f"Could not generate image due to: {str(e)}. Embedding interactive plot.")
            fig_json = fig.to_json()
            html += f"""
            <div class="figure">
                <div id="plotly-aqi" style="width:100%;height:400px;"></div>
                <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
                <script>
                    var aqiData = {fig_json};
                    Plotly.newPlot('plotly-aqi', aqiData.data, aqiData.layout);
                </script>
                <div class="caption">Figure 5: Distribution of Air Quality Index Categories</div>
            </div>
            """
        
        # AQI explanation
        html += """
        <h3>AQI Category Definitions</h3>
        <table>
            <tr>
                <th>AQI Category</th>
                <th>AQI Range</th>
                <th>Health Implications</th>
            </tr>
            <tr>
                <td>Good</td>
                <td>0-50</td>
                <td>Air quality is satisfactory, and air pollution poses little or no risk.</td>
            </tr>
            <tr>
                <td>Moderate</td>
                <td>51-100</td>
                <td>Air quality is acceptable. However, there may be a risk for some people, particularly those who are unusually sensitive to air pollution.</td>
            </tr>
            <tr>
                <td>Unhealthy for Sensitive Groups</td>
                <td>101-150</td>
                <td>Members of sensitive groups may experience health effects. The general public is less likely to be affected.</td>
            </tr>
            <tr>
                <td>Unhealthy</td>
                <td>151-200</td>
                <td>Some members of the general public may experience health effects; members of sensitive groups may experience more serious health effects.</td>
            </tr>
            <tr>
                <td>Very Unhealthy</td>
                <td>201-300</td>
                <td>Health alert: The risk of health effects is increased for everyone.</td>
            </tr>
            <tr>
                <td>Hazardous</td>
                <td>301-500</td>
                <td>Health warning of emergency conditions: everyone is more likely to be affected.</td>
            </tr>
        </table>
        """
        
        html += """
        </div>
        """
    
    # AI Recommendations Section
    if include_recommendations and ai_recommendations:
        html += """
        <div class="section">
            <h2>AI-Powered Insights & Recommendations</h2>
            <div class="recommendations">
        """
        
        # Format the AI recommendations
        formatted_recommendations = ai_recommendations.replace('\n', '<br>')
        
        html += f"""
            {formatted_recommendations}
        """
        
        html += """
            </div>
        </div>
        """
    
    # Footer
    html += f"""
        <footer>
            <p>© {datetime.now().year} Air Quality Analytics Dashboard • Generated on {date}</p>
        </footer>
    </body>
    </html>
    """
    
    return html

def html_to_pdf(html_content):
    """
    Convert HTML to PDF-like format (actually HTML, since we can't generate PDF directly).
    
    Args:
        html_content: str - HTML content to convert
        
    Returns:
        bytes: PDF-like data as bytes
    """
    # Since we can't generate actual PDFs without external libraries,
    # we'll return the HTML content directly as bytes
    return html_content.encode()
