import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime

from utils.visualization import (
    create_correlation_heatmap,
    plot_time_series,
    create_daily_pattern_chart,
    create_pollutant_rose,
    create_aqi_distribution,
    create_device_comparison_chart
)
from utils.data_processor import calculate_aqi, get_data_summary
from utils.ai_insights import get_threshold_recommendations

# Import styled components from assets
from assets.icons import (
    get_kpi_card,
    get_aqi_card,
    FLOATING_ANIMATION,
    get_floating_icons_html,
    LEAF_ICON,
    CLOUD_ICON, 
    SUN_ICON, 
    THERMOMETER_ICON,
    WATER_DROP_ICON,
    WIND_ICON,
    PULSE_ANIMATION
)

def render_dashboard(df, ai_recommendations):
    """
    Render the main dashboard with visualizations and insights.
    
    Args:
        df: pandas.DataFrame - The data to visualize
        ai_recommendations: str - AI-generated recommendations
    """
    # Header with simple title (no HTML)
    st.subheader("Dashboard Overview")
    
    if df is None or df.empty:
        st.warning("No data available to display. Please upload data files or load sample data.")
        return
    
    # Calculate AQI if not already present
    if 'AQI' not in df.columns:
        df = calculate_aqi(df)
    
    # Get data summary
    summary = get_data_summary(df)
    
    # Display key stats in styled cards
    st.subheader("Key Metrics")
    
    metrics_row1 = st.columns(4)
    metrics_row2 = st.columns(4)
    
    # Row 1 - Common metrics
    with metrics_row1[0]:
        pm25_avg = df['PM2.5'].mean() if 'PM2.5' in df.columns else None
        if pm25_avg is not None:
            st.metric(
                label="PM2.5 (µg/m³)",
                value=f"{pm25_avg:.1f}"
            )
            
            # Display additional info about PM2.5
            st.caption("Particulate Matter ≤ 2.5µm")
            
            # Get previous day average (for trend)
            if len(df) > 48:  # If we have more than 2 days of hourly data
                previous_df = df.sort_values('Datetime').iloc[:-24]
                prev_pm25_avg = previous_df['PM2.5'].mean()
                change_pct = ((pm25_avg - prev_pm25_avg) / prev_pm25_avg) * 100
                st.caption(f"Change: {change_pct:.1f}% from previous day")
            
    with metrics_row1[1]:
        pm10_avg = df['PM10'].mean() if 'PM10' in df.columns else None
        if pm10_avg is not None:
            # Use Streamlit's native metric component
            delta = None
            
            # Get previous day average (for delta)
            if len(df) > 48:  # If we have more than 2 days of hourly data
                previous_df = df.sort_values('Datetime').iloc[:-24]
                prev_pm10_avg = previous_df['PM10'].mean()
                change_pct = ((pm10_avg - prev_pm10_avg) / prev_pm10_avg) * 100
                delta = f"{change_pct:.1f}%"
            
            st.metric(
                label="PM10 (µg/m³)",
                value=f"{pm10_avg:.1f}",
                delta=delta
            )
            
            # Display additional info about PM10
            st.caption("Particulate Matter ≤ 10µm")
                
    with metrics_row1[2]:
        temp_avg = df['Temperature'].mean() if 'Temperature' in df.columns else None
        if temp_avg is not None:
            st.metric(
                label="Temperature (°C)",
                value=f"{temp_avg:.1f}"
            )
            st.caption("Average ambient temperature")
            
    with metrics_row1[3]:
        humidity_avg = df['Humidity'].mean() if 'Humidity' in df.columns else None
        if humidity_avg is not None:
            st.metric(
                label="Humidity (%)",
                value=f"{humidity_avg:.1f}"
            )
            st.caption("Relative humidity")
    
    # Row 2 - AQI and additional metrics
    with metrics_row2[0]:
        if 'AQI' in df.columns and 'AQI_Category' in df.columns:
            aqi_avg = df['AQI'].mean()
            # Get most common AQI category
            aqi_category = df['AQI_Category'].mode()[0]
            
            # Define color based on AQI category
            colors = {
                "Good": "#4BB051",  # Green
                "Moderate": "#F5DD42",  # Yellow
                "Unhealthy for Sensitive Groups": "#F59C42",  # Orange
                "Unhealthy": "#EB6769",  # Red
                "Very Unhealthy": "#A470B8",  # Purple
                "Hazardous": "#A06A7B"  # Maroon
            }
            
            st.metric(
                label=f"Air Quality Index ({aqi_category})",
                value=f"{aqi_avg:.0f}"
            )
            
            # Add a colored indicator based on AQI category
            category_color = colors.get(aqi_category, "#4BB051")
            st.markdown(f"""
                <div style="background-color: {category_color}; 
                            width: 100%; 
                            height: 10px; 
                            border-radius: 5px;">
                </div>
            """, unsafe_allow_html=True)
            
            st.caption("Based on US EPA AQI standard")
    
    # Additional metrics for row 2 if available
    with metrics_row2[1]:
        if 'CO2' in df.columns:
            co2_avg = df['CO2'].mean()
            st.metric(
                label="CO₂ (ppm)",
                value=f"{co2_avg:.1f}"
            )
            st.caption("Carbon dioxide concentration")
            
    with metrics_row2[2]:
        if 'Pressure' in df.columns:
            pressure_avg = df['Pressure'].mean()
            st.metric(
                label="Pressure (hPa)",
                value=f"{pressure_avg:.1f}"
            )
            st.caption("Atmospheric pressure")
            
    with metrics_row2[3]:
        if 'Wind_Speed' in df.columns:
            wind_avg = df['Wind_Speed'].mean()
            st.metric(
                label="Wind Speed (m/s)",
                value=f"{wind_avg:.1f}"
            )
            st.caption("Average wind velocity")
    
    # Main dashboard tabs
    tab1, tab2, tab3, tab4 = st.tabs([
        "Time Series Analysis", 
        "Correlation Analysis", 
        "Device Comparison",
        "AI Insights"
    ])
    
    with tab1:
        st.subheader("Time Series Analysis")
        
        # Time series controls
        col1, col2 = st.columns([3, 1])
        
        with col1:
            # Allow users to select metrics for time series
            available_metrics = [
                col for col in df.columns 
                if col not in ['Datetime', 'Time', 'Device_ID', 'Geohash', 'AQI', 'AQI_Category'] 
                and df[col].dtype in ['float64', 'int64']
            ]
            
            selected_metrics = st.multiselect(
                "Select Metrics to Plot",
                options=available_metrics,
                default=['PM2.5', 'PM10', 'Temperature'][:min(3, len(available_metrics))]
            )
        
        with col2:
            # Removed aggregation options as it was causing issues
            st.info("Time series showing raw data")
        
        # Time series plot
        if selected_metrics:
            # Use data without aggregation
            plot_df = df.copy()
            
            fig = plot_time_series(plot_df, metrics=selected_metrics)
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("Please select at least one metric to plot")
        
        # Daily patterns
        st.subheader("Daily Patterns")
        
        # Let users select a metric for daily pattern analysis
        pattern_metric = st.selectbox(
            "Select Metric for Daily Pattern Analysis",
            options=available_metrics,
            index=available_metrics.index('PM2.5') if 'PM2.5' in available_metrics else 0
        )
        
        fig_daily = create_daily_pattern_chart(df, metric=pattern_metric)
        st.plotly_chart(fig_daily, use_container_width=True)
        
        # AQI distribution if available
        if 'AQI_Category' in df.columns:
            st.subheader("Air Quality Index Distribution")
            fig_aqi = create_aqi_distribution(df)
            st.plotly_chart(fig_aqi, use_container_width=True)
    
    with tab2:
        st.subheader("Correlation Analysis")
        
        # Correlation heatmap
        fig_corr = create_correlation_heatmap(df)
        st.plotly_chart(fig_corr, use_container_width=True)
        
        # Pollutant rose (wind direction vs. pollutant)
        if 'Wind_Direction' in df.columns:
            st.subheader("Pollutant Rose")
            
            # Let users select a pollutant for the rose chart
            pollutants = [col for col in df.columns if col.startswith('PM') and df[col].dtype in ['float64', 'int64']]
            if pollutants:
                selected_pollutant = st.selectbox(
                    "Select Pollutant",
                    options=pollutants,
                    index=0
                )
                
                fig_rose = create_pollutant_rose(df, pollutant=selected_pollutant)
                st.plotly_chart(fig_rose, use_container_width=True)
            else:
                st.info("No pollutant data available for wind direction analysis")
        else:
            st.info("Wind direction data not available")
    
    with tab3:
        st.subheader("Device Comparison")
        
        if 'Device_ID' in df.columns and df['Device_ID'].nunique() > 1:
            # Let users select a metric for device comparison
            device_metric = st.selectbox(
                "Select Metric for Device Comparison",
                options=available_metrics,
                index=available_metrics.index('PM2.5') if 'PM2.5' in available_metrics else 0
            )
            
            fig_devices = create_device_comparison_chart(df, metric=device_metric)
            st.plotly_chart(fig_devices, use_container_width=True)
            
            # Map view preview (simplified)
            st.subheader("Device Locations")
            if 'Geohash' in df.columns and not df['Geohash'].isna().all():
                st.info("Full map view available in the Map View tab")
                from components.map_view import create_simple_map
                simplified_map = create_simple_map(df)
                st.plotly_chart(simplified_map, use_container_width=True)
            else:
                st.info("Geospatial data not available for mapping")
        else:
            st.info("Multiple device data not available for comparison")
    
    with tab4:
        st.subheader("AI-Powered Insights")
        
        if ai_recommendations and "Error" not in ai_recommendations and "⚠️" not in ai_recommendations:
            st.markdown(ai_recommendations)
        else:
            st.warning(ai_recommendations if ai_recommendations else "AI recommendations not available.")
            
            # Show threshold-based recommendations as fallback
            st.subheader("Threshold-Based Recommendations")
            recommendations = get_threshold_recommendations(df)
            
            if recommendations:
                for pollutant, rec in recommendations.items():
                    with st.expander(f"{pollutant} - {rec['level']}"):
                        st.markdown(f"**Description:** {rec['description']}")
                        st.markdown(f"**Advice:** {rec['advice']}")
            else:
                st.info("No threshold-based recommendations available.")
