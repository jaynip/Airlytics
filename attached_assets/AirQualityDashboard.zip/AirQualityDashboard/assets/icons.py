"""
SVG icons and animations for the Air Quality Dashboard.
These can be embedded directly in Streamlit using st.markdown with unsafe_allow_html=True.
"""

# Air quality and environmental SVG icons
LEAF_ICON = """
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="#4bb051">
    <path d="M17.75 3.08 21.25 4.08C21.67 4.2 22 4.6 22 5.05V16.05C22 16.4 21.8 16.7 21.48 16.87L13.4 21.5C13.15 21.65 12.85 21.65 12.6 21.5L4.52 16.87C4.2 16.7 4 16.4 4 16.05V5.05C4 4.6 4.33 4.2 4.75 4.08L8.25 3.08C8.67 2.95 9.12 3.12 9.38 3.5L12 7.5L14.62 3.5C14.88 3.12 15.33 2.95 15.75 3.08ZM12 15.88L18 12.38V5.8L14.87 6.7L12.05 11.18C11.87 11.47 11.58 11.62 11.28 11.62C10.95 11.62 10.67 11.47 10.5 11.18L7.68 6.7L4.55 5.8V12.38Z" />
</svg>
"""

CLOUD_ICON = """
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="#88BFFF">
    <path d="M19.19 12.07C18.85 9.1 16.3 6.85 13.21 6.85C10.8 6.85 8.71 8.34 7.74 10.42C5.24 10.84 3.3 12.96 3.3 15.57C3.3 18.48 5.67 20.85 8.58 20.85H18.97C21.17 20.85 22.95 19.07 22.95 16.87C22.95 14.85 21.34 13.15 19.19 12.07Z" />
</svg>
"""

WIND_ICON = """
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="#c0c0c0">
    <path d="M4 10h12v2H4v-2zm0-4h8v2H4V6zm0 8h8v2H4v-2zm10 0h4v2h-4v-2zm5-8c.6 0 1 .4 1 1v1h-2V7c0-.6.4-1 1-1z" />
</svg>
"""

SUN_ICON = """
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="#FDB813">
    <path d="M12 7c-2.76 0-5 2.24-5 5s2.24 5 5 5 5-2.24 5-5-2.24-5-5-5zM2 13h2c.55 0 1-.45 1-1s-.45-1-1-1H2c-.55 0-1 .45-1 1s.45 1 1 1zm18 0h2c.55 0 1-.45 1-1s-.45-1-1-1h-2c-.55 0-1 .45-1 1s.45 1 1 1zM11 2v2c0 .55.45 1 1 1s1-.45 1-1V2c0-.55-.45-1-1-1s-1 .45-1 1zm0 18v2c0 .55.45 1 1 1s1-.45 1-1v-2c0-.55-.45-1-1-1s-1 .45-1 1zM5.99 4.58c-.39-.39-1.03-.39-1.41 0-.39.39-.39 1.03 0 1.41l1.06 1.06c.39.39 1.03.39 1.41 0 .39-.39.39-1.03 0-1.41L5.99 4.58zm12.37 12.37c-.39-.39-1.03-.39-1.41 0-.39.39-.39 1.03 0 1.41l1.06 1.06c.39.39 1.03.39 1.41 0 .39-.39.39-1.03 0-1.41l-1.06-1.06zm1.06-10.96c.39-.39.39-1.03 0-1.41-.39-.39-1.03-.39-1.41 0l-1.06 1.06c-.39.39-.39 1.03 0 1.41.39.39 1.03.39 1.41 0l1.06-1.06zM7.05 18.36c.39-.39.39-1.03 0-1.41-.39-.39-1.03-.39-1.41 0l-1.06 1.06c-.39.39-.39 1.03 0 1.41.39.39 1.03.39 1.41 0l1.06-1.06z" />
</svg>
"""

THERMOMETER_ICON = """
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="#FF5722">
    <path d="M15 16c0 1.66-1.34 3-3 3s-3-1.34-3-3c0-.83.34-1.58.88-2.12l2.12-11.88 2.12 11.88c.54.54.88 1.29.88 2.12zm-3 1c.55 0 1-.45 1-1s-.45-1-1-1-1 .45-1 1 .45 1 1 1zm5-9.5c0 4.14-2.36 7.5-5.25 7.5s-5.25-3.36-5.25-7.5c0-.55.45-1 1-1s1 .45 1 1c0 3.05 1.75 5.5 3.25 5.5s3.25-2.45 3.25-5.5c0-.55.45-1 1-1s1 .45 1 1zm-1.5-3c0 .83-.67 1.5-1.5 1.5s-1.5-.67-1.5-1.5.67-1.5 1.5-1.5 1.5.67 1.5 1.5z" />
</svg>
"""

WATER_DROP_ICON = """
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="#64B5F6">
    <path d="M12 2.5c2.33 5.45 7 8.11 7 12.5 0 3.87-3.13 7-7 7s-7-3.13-7-7c0-4.39 4.67-7.05 7-12.5zm0 15c1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3 1.34 3 3 3z" />
</svg>
"""

# Air quality category icons
AQI_GOOD_ICON = """
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="#4BB051">
    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z" />
</svg>
"""

AQI_MODERATE_ICON = """
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="#FFDD33">
    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm-1-13h2v6h-2zm0 8h2v2h-2z" />
</svg>
"""

AQI_UNHEALTHY_ICON = """
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="#FF5722">
    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 15h2v2h-2v-2zm0-8h2v6h-2V9z" />
</svg>
"""

# CSS Animations
FLOATING_ANIMATION = """
<style>
@keyframes float {
  0% { transform: translateY(0px); }
  50% { transform: translateY(-10px); }
  100% { transform: translateY(0px); }
}
.float {
  animation: float 3s ease-in-out infinite;
  display: inline-block;
}
.float-1 { animation-delay: 0s; }
.float-2 { animation-delay: 0.5s; }
.float-3 { animation-delay: 1s; }
.float-4 { animation-delay: 1.5s; }
.float-5 { animation-delay: 2s; }
</style>
"""

PULSE_ANIMATION = """
<style>
@keyframes pulse {
  0% { transform: scale(1); opacity: 1; }
  50% { transform: scale(1.1); opacity: 0.8; }
  100% { transform: scale(1); opacity: 1; }
}
.pulse {
  animation: pulse 2s ease-in-out infinite;
  display: inline-block;
}
</style>
"""

ROTATE_ANIMATION = """
<style>
@keyframes rotate {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
.rotate {
  animation: rotate 5s linear infinite;
  display: inline-block;
  transform-origin: center;
}
</style>
"""

# KPI Cards with Icons
def get_kpi_card(title, value, icon, unit="", trend=None, trend_value=None, color="#4BB051"):
    """Generate HTML for a KPI card with icon and optional trend indicator."""
    trend_html = ""
    if trend is not None and trend_value is not None:
        arrow = "↑" if trend == "up" else "↓"
        trend_color = "#FF5722" if trend == "up" else "#4BB051"
        if (trend == "up" and title in ["PM2.5", "PM10"]) or (trend == "down" and title not in ["PM2.5", "PM10"]):
            trend_color = "#FF5722"  # Red for bad trends
        else:
            trend_color = "#4BB051"  # Green for good trends
        
        trend_html = f"""
        <div style="font-size: 0.8rem; color: {trend_color}; margin-top: 5px;">
            {arrow} {trend_value}%
        </div>
        """
    
    return f"""
    <div style="background-color: white; border-radius: 10px; padding: 15px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); margin-bottom: 15px; border-left: 5px solid {color};">
        <div style="display: flex; align-items: center; margin-bottom: 10px;">
            <div style="margin-right: 10px;">
                {icon}
            </div>
            <div style="font-size: 1rem; color: #666;">{title}</div>
        </div>
        <div style="font-size: 1.8rem; font-weight: bold; color: #333; margin-top: 5px;">
            {value} <span style="font-size: 0.9rem; font-weight: normal; color: #888;">{unit}</span>
        </div>
        {trend_html}
    </div>
    """

def get_floating_icons_html(count=5):
    """Generate HTML for floating environmental icons."""
    icons = [LEAF_ICON, CLOUD_ICON, SUN_ICON, WATER_DROP_ICON, WIND_ICON]
    html = FLOATING_ANIMATION + PULSE_ANIMATION + ROTATE_ANIMATION
    html += '<div style="text-align: center; padding: 10px 0;">'
    
    for i in range(count):
        icon = icons[i % len(icons)]
        html += f'<span class="float float-{(i % 5) + 1}" style="margin: 0 10px;">{icon}</span>'
    
    html += '</div>'
    return html

# Banner with logo and animation
def get_banner_html(title="Air Quality Analytics Dashboard", subtitle="AI-powered air quality monitoring and analysis"):
    """Generate HTML for a banner with static icons."""
    return f"""
    <div style="display: flex; align-items: center; margin-bottom: 20px; background: linear-gradient(90deg, #4bb051 0%, #9cd4a4 100%); padding: 20px; border-radius: 10px; color: white;">
        <div style="margin-right: 20px;">
            {LEAF_ICON.replace('width="24"', 'width="36"').replace('height="24"', 'height="36"')}
        </div>
        <div>
            <h1 style="margin: 0; font-size: 1.8rem;">{title}</h1>
            <p style="margin: 5px 0 0 0; opacity: 0.9;">{subtitle}</p>
        </div>
    </div>
    """

# AQI Index card with color coding
def get_aqi_card(aqi_value, category):
    """Generate HTML for an AQI card with appropriate coloring."""
    color = "#4BB051"  # Default green
    icon = AQI_GOOD_ICON
    
    if category == "Good":
        color = "#4BB051"  # Green
        icon = AQI_GOOD_ICON
    elif category == "Moderate":
        color = "#FFDD33"  # Yellow
        icon = AQI_MODERATE_ICON
    elif category == "Unhealthy for Sensitive Groups":
        color = "#FF9933"  # Orange
        icon = AQI_MODERATE_ICON
    elif category == "Unhealthy":
        color = "#FF5722"  # Red
        icon = AQI_UNHEALTHY_ICON
    elif category == "Very Unhealthy":
        color = "#A970FF"  # Purple
        icon = AQI_UNHEALTHY_ICON
    elif category == "Hazardous":
        color = "#A52A2A"  # Maroon
        icon = AQI_UNHEALTHY_ICON
    
    return f"""
    <div style="background-color: white; border-radius: 10px; padding: 15px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); margin-bottom: 15px; border-left: 5px solid {color};">
        <div style="display: flex; align-items: center; margin-bottom: 10px;">
            <div style="margin-right: 10px;">
                {icon}
            </div>
            <div style="font-size: 1rem; color: #666;">Air Quality Index</div>
        </div>
        <div style="font-size: 1.8rem; font-weight: bold; color: #333; margin-top: 5px;">
            {aqi_value}
        </div>
        <div style="font-size: 1rem; color: {color}; margin-top: 5px;">
            {category}
        </div>
    </div>
    """