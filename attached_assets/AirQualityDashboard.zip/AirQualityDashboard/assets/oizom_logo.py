"""
Oizom logo as SVG for the Air Quality Dashboard.
"""

# Oizom logo as SVG
OIZOM_LOGO = """
<svg width="120" height="50" viewBox="0 0 120 50" xmlns="http://www.w3.org/2000/svg">
  <g fill="#4bb051">
    <path d="M25.5,10 C33.5,10 40,16.5 40,24.5 C40,32.5 33.5,39 25.5,39 C17.5,39 11,32.5 11,24.5 C11,16.5 17.5,10 25.5,10 Z M25.5,15 C20.3,15 16,19.3 16,24.5 C16,29.7 20.3,34 25.5,34 C30.7,34 35,29.7 35,24.5 C35,19.3 30.7,15 25.5,15 Z"/>
    <path d="M25.5,15 L25.5,34 L16,24.5 Z"/>
    <path d="M47,15 L47,33 L53,33 L53,15 Z"/>
    <path d="M60,15 C54.5,15 50,19.5 50,25 C50,30.5 54.5,35 60,35 C65.5,35 70,30.5 70,25 C70,19.5 65.5,15 60,15 Z M60,20 C62.8,20 65,22.2 65,25 C65,27.8 62.8,30 60,30 C57.2,30 55,27.8 55,25 C55,22.2 57.2,20 60,20 Z"/>
    <path d="M75,12 L75,35 L80,35 L80,23 L88,35 L94,35 L85,22 L93,12 L87,12 L80,22 L80,12 Z"/>
  </g>
</svg>
"""

# Oizom logo as base64 image (if needed)
OIZOM_LOGO_BASE64 = ""

def get_oizom_logo_html(width=120):
    """Return HTML with Oizom logo at specified width"""
    return f"""
    <div style="display: flex; justify-content: center; margin-bottom: 10px;">
        {OIZOM_LOGO.replace('width="120"', f'width="{width}"')}
    </div>
    """